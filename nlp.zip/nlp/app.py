from flask import Flask, request, render_template_string
from transformers import PegasusTokenizer, PegasusForConditionalGeneration

app = Flask(__name__)

print("Loading model and tokenizer...")
model_name = "google/pegasus-xsum"
tokenizer = PegasusTokenizer.from_pretrained(model_name)
model = PegasusForConditionalGeneration.from_pretrained(model_name)
print("Model and tokenizer loaded successfully.")

def summarize(text, max_length=150, min_length=50, num_beams=4):
    print("Summarizing text...")
    inputs = tokenizer([text], max_length=1024, return_tensors='pt', truncation=True)
    summary_ids = model.generate(
        inputs['input_ids'], 
        max_length=max_length, 
        min_length=min_length, 
        num_beams=num_beams, 
        length_penalty=2.0, 
        early_stopping=True
    )
    summary = tokenizer.decode(summary_ids[0], skip_special_tokens=True)
    print("Summary generated.")
    return summary

@app.route('/')
def home():
    return render_template_string('''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Text Summarizer</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #ffcccc;
                    padding: 20px;
                }
                h1 {
                    text-align: center;
                    margin-bottom: 20px;
                }
                textarea {
                    width: 100%;
                    padding: 10px;
                    font-size: 16px;
                    border: 1px solid #ccc;
                    border-radius: 4px;
                    resize: vertical;
                }
                input[type="submit"] {
                    background-color: #4CAF50; /* Green */
                    color: white;
                    padding: 10px 20px;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    float: right;
                }
                input[type="submit"]:hover {
                    background-color: #45a049;
                }
                .summary-container {
                    background-color: white;
                    padding: 20px;
                    margin-top: 20px;
                    border-radius: 8px;
                    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
                }
                .summary {
                    margin-top: 10px;
                    font-size: 18px;
                    line-height: 1.6;
                }
                .back-link {
                    display: block;
                    margin-top: 20px;
                    text-align: center;
                }
            </style>
        </head>
        <body>
            <h1>Text Summarizer</h1>
            <form action="/summarize" method="post">
                <textarea name="text" rows="10" placeholder="Enter the text you want to summarize..."></textarea><br><br>
                <input type="submit" value="Summarize">
            </form>
        </body>
        </html>
    ''')

@app.route('/summarize', methods=['POST'])
def summarize_text():
    text = request.form['text']
    print("Text received for summarization:", text)
    summary = summarize(text)
    return render_template_string('''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Summary</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color:  #a6e4e7;
                    padding: 20px;
                }
                h1 {
                    text-align: center;
                    margin-bottom: 20px;
                }
                .summary-container {
                    background-color: white;
                    padding: 20px;
                    margin-top: 20px;
                    border-radius: 8px;
                    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
                }
                .summary {
                    margin-top: 10px;
                    font-size: 18px;
                    line-height: 1.6;
                }
                .back-link {
                    display: block;
                    margin-top: 20px;
                    text-align: center;
                }
            </style>
        </head>
        <body>
            <h1>Summary</h1>
            <div class="summary-container" style="background-color: #f0f0f0; padding: 20px;">
                <p class="summary">{{ summary }}</p>
                <a href="/" class="back-link">Back to Home</a>
            </div>
        </body>
        </html>
    ''', summary=summary)

if __name__ == '__main__':
    print("Starting Flask app...")
    app.run(debug=True)
